These are the original greyscale renditions of the beta Pokemon, without my speculative recolours. 
