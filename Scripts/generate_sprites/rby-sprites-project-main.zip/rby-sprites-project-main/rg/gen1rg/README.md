These are the RG sprites seen on Pokemon Showdown's index. I worked on situating these in this way with this transparency.

Not sure if this needs anything. I guess MissingNo., but that should ideally be in an upcoming glitchmon folder.
