This is a repository of Red and Green's sprites. These are the first interpretations of the original 151 that were ever released, produced in the early 90's.

As of now, my archive has the following;
- The standard front and back sprites
- PS-compatible canvases, many of which had transparency edits done by myself.
- Colour-corrected versions
- 250% enlarged versions
- Cropped to sprite versions
- 56x56 front sprites

Things I'd like to add down the line;
- Glitch Pokemon, possibly adjusted for PS, palette, and transparency.
- Pixel-for-pixel reconstructions of Capsule Monsters prototype material (eg. the "original 16" sprite sheet, etc)
