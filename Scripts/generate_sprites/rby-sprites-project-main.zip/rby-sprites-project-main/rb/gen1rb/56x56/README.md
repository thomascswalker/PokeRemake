These sprites use numerical ordering for easier organisation.

This folder is a work-in-progress that uses a clone of the Yellow section to more easily replace things. Contribute as desired.
