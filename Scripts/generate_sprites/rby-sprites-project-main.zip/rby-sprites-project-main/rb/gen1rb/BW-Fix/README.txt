These are the same May '98 sprites but with the white and black changed to be pure white/black. This is, theoretically, how the sprites were intended to be designed. Additionally, there are versions cropped+numbered and enlarged for extra utility.

Credit to Frrf for making a script to automatically process these, it saved a lot of time!