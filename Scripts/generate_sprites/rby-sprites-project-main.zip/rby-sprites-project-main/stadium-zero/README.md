These are models from the Japan-only Stadium game, the first one released. In the west, we actually got the second one first. That was intended to be this product, only expanded with the N64 DD. 

You'll see two versions of each model: compressed and uncompressed. Compressed versions are intended for use with Pokemon Showdown, downsized with reduced MBs to make them load sufficiently quickly for a seamless experience. Uncompressed versions feature much larger models for use with other material.

This archive is a heavy work in progress and relies on a texture pack using the Pokedex feature and some editing magic. For details on the process, look here: https://www.smogon.com/forums/threads/implement-stadium-model-sprites.3702938/post-9238606

Because this elaborate method uses the Pokedex feature, some models will go off-screen. I've kept these to a minimum thus-far. There is most definitely a better method of extracting these, I just don't know what.
