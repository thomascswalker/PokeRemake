These sprites use numerical ordering for easier organisation. 
