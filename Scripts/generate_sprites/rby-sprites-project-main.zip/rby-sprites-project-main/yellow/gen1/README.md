These are the Yellow sprites seen on Pokemon Showdown's index. I worked on situating these in this way with this transparency. 

It also includes the MissingNo. variants, though these are technically wrong: they're the RB palette. I intend to amend these sometime. 
