The 2018 gigaleak featured many old revisions of Yellow front sprites from when its development was just starting. Many of these feature different poses, old ideas, or simply less refined stuff. Specifically, they were in the May '98 archive from when Pokemon Pink was under consideration for a joint release alongside Yellow. Thus, these sprites were also developed concurrently with the SpaceWorld '97 sprites, which had continued to be modified at the same time.

The following Pokemon have different sprites from the final version;
- Arcanine
- Butterfree
- Caterpie
- Charmander
- Dodrio
- Farfetch'd
- Pikachu
- Rattata
- Raticate
- Jolteon
- Spearow
- Weedle

Nothing else was present in the cache, so everything else included here is for Tampermonkey script compatability.
