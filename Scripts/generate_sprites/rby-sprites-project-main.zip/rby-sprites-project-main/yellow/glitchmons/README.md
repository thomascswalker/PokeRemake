A project I'll likely never get to. This would house all the Yellow glitch Pokemon on a PS canvas, intended for use with Showdown.
