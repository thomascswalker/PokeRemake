These are the Spaceworld '97 front and back sprites for the original 151, which have art styles reminiscent of the originals. While they are dated November 1997, they could have been made a bit earlier than this. 

Some of the sprites here are actually still the Pocket Monsters Aoi sprites, implying some of these were meant to be in Blue in the first place, especially given some look like less polished versions (eg. Golem). The back sprites here are of incredible quality compared to the original games while also featuring the old design concepts, making them mesh very well with Red, Green, and Blue's sprites.

As of now, my archive has the following;
- The standard front and back sprites
- PS-compatible canvases, many of which had transparency edits done by myself.
- Colour-corrected versions
- 250% enlarged versions
- Cropped to sprite versions