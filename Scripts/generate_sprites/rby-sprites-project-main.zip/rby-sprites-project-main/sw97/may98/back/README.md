Completed 14th June 2022.
Palettes may be update-able. Not sure.
